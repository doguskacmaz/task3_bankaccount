    fn main() {
        
    let mut new_account_1 = BankAccount {account_number: 1,holder_name: String::from ("Bob"), balance: 115.00};

    let mut new_account_2 = BankAccount {account_number: 2,holder_name: String::from("Jack"), balance: 250.00};

    new_account_1.deposit(50.0);
    new_account_2.withdraw(163.5);

    

    new_account_1.balance();
    new_account_2.balance();

    }   

    trait Account {
        fn deposit (&mut self, x:f64);


        fn withdraw (&mut self, x:f64);


        fn balance (&self);
    }

    

        


    struct BankAccount{
        account_number:i32,
        holder_name :String,
        balance :f64,
    }

    impl Account for BankAccount{

        fn deposit (&mut self, x:f64){
            self.balance += x;

        }


        fn withdraw (&mut self, x:f64)
        {
            self.balance -= x;
        }


        fn balance (&self) 
        {
            println!("Account {} with balance ${}, holder name is {}",&self.account_number, &self.balance, &self.holder_name);       
        }
    }








    //Call the balance method on both accounts and print the result to the console.
    //Compile and run the program to ensure it works as expected.